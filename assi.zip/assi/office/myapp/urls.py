from django.urls import path
from . import views

urlpatterns = [
    path('',views.office_list,name='office_list'),
    path('create/',views.office_create,name='office_create'),
     path('get/<int:id>/',views.get_task,name='get_task'),
    path('delete/<int:id>/',views.office_delete,name='office_delete'),
    path('update/<int:id>/',views.office_update,name='office_update'),
]
