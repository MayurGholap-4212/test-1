from django.shortcuts import render,redirect,get_object_or_404
from .models import Office

# Create your views here.
def office_list(request):
    record=Office.objects.all()
    return render(request,'office_list.html',{'record':record})

def office_create(request):
    if request.method=='POST':
        name=request.POST.get('name')
        location=request.POST.get('location')
        employee_count=request.POST.get('employee_count')
        Office.objects.create(name=name,location=location,employee_count=employee_count)
        return redirect('office_list')
    return render(request,'office_create.html')


def office_delete(request, id):
    record=get_object_or_404(Office,id=id)
    record.delete()
    return redirect('office_list')

def get_task(request,id):
    record=get_object_or_404(Office,id=id)
    return render(request,'office_details.html',{'record':record})

def office_update(request,id):
    record=get_object_or_404(Office,id=id)
    if request.method=="POST":
        name=request.POST.get('name')
        location=request.POST.get('location')
        employee_count=request.POST.get('employee_count')
        record.name=name
        record.location=location
        record.employee_count=employee_count
        record.save()
        return redirect('office_list')
    return render(request,'office_update.html',{'record':record})